#include "Node.h"
#include <iostream>
using namespace std;
template <typename T>
class LinkedList
{

private:
    Node<T>* Head;    //Pointer to the head of the list
    //You can add tail pointer too (depending on your problem)
public:


    LinkedList()
    {
        Head = nullptr;
    }
    LinkedList(const LinkedList<T>& L) {
        Head = NULL;
        Node<T>* temp = L.Head;
        Node<T>* temp2 = NULL;
        while (temp) {
            if (!Head) {
                Head = new Node<T>(temp->getItem());
                temp2 = Head;
            }

            else {
                Node<T>* x = new Node<T>(temp->getItem());
                temp2->setNext(x);
                temp2 = temp2->getNext();

            }

            temp = temp->getNext();
        }

    }
    //List is being desturcted ==> delete all items in the list
    ~LinkedList()
    {
        DeleteAll();
    }
    ////////////////////////////////////////////////////////////////////////
    /*
    * Function: PrintList.
    * prints the values of all nodes in a linked list.
    */
    void PrintList() const
    {
        Node<T>* p = Head;
        while (p)
        {
            cout << p->getItem(); p = p->getNext();
            // if (p)
            cout << " ";
        }
        cout << "NULL\n";
    }
    ////////////////////////////////////////////////////////////////////////
    /*
    * Function: InsertBeg.
    * Creates a new node and adds it to the beginning of a linked list.
    *
    * Parameters:
    *    - data : The value to be stored in the new node.
    */
    void InsertBeg(const T& data)
    {
        Node<T>* R = new Node<T>(data);
        R->setNext(Head);
        Head = R;

    }
    ////////////////////////////////////////////////////////////////////////
    /*
    * Function: DeleteAll.
    * Deletes all nodes of the list.
    */
    void DeleteAll()
    {
        Node<T>* P = Head;
        while (Head)
        {
            P = Head->getNext();
            delete Head;
            Head = P;
        }
    }



    ////////////////     Requirements   ///////////////////
    //
    // Implement the following member functions


    //[1]InsertEnd 
    //inserts a new node at end if the list
    void InsertEnd(const T& data)
    {
        Node<T>* end = new Node<T>(data);
        Node<T>* tail;
        if (!Head)
        {
            Head = end;
            Head->setNext(nullptr);
            return;
        }
        for (tail = Head; tail->getNext(); tail = tail->getNext())
            ;
        tail->setNext(end);
        tail = end;
    }

    //[2]Find 
    //searches for a given value in the list, returns true if found; false otherwise.
    bool Find(int Key);

    //[3]CountOccurance
    //returns how many times a certain value appeared in the list
    int CountOccurance(const T& value);

    //[4] DeleteFirst
    //Deletes the first node in the list
    void DeleteFirst();


    //[5] DeleteLast
    //Deletes the last node in the list
    void DeleteLast();

    //[6] DeleteNode
    //deletes the first node with the given value (if found) and returns true
    //if not found, returns false
    //Note: List is not sorted
    bool DeleteNode(const T& value);

    //[7] DeleteNodes
    //deletes ALL node with the given value (if found) and returns true
    //if not found, returns false
    //Note: List is not sorted
    bool DeleteNodes(const T& value);

    //[8]Merge
    //Merges the current list to another list L by making the last Node in the current list 
    //point to the first Node in list L
    void Merge(const LinkedList& L);

    //[9] Reverse
    //Reverses the linked list (without allocating any new Nodes)
    void Reverse();

    ////////////////////////////////////////////////////////////////////////////
    ///      23th April Assignment
    ////////////////////////////////////////////////////////////////////////////
    template <class U>
    friend class LinkedList;
    void reverse(Node<T>*& l)
    {
        if (!l || !l->getNext())
            return;
        Node<T>* prev = l;
        Node<T>* tail = l;
        while (tail->getNext())
            tail = tail->getNext();

        Node<T>* cur = l->getNext();
        //l = l->getNext();
        while (cur)
        {
            Node<T>* temp = cur->getNext();
            cur->setNext(prev);
            prev = cur;
            cur = temp;
            //temp = temp->getNext();
        }
        Node<T>* temp = l;
        l = tail;
        tail = temp;
        tail->setNext(nullptr);
    }
    void RearrangeLL()
    {
        if (!Head || !Head->getNext())
            return;
        int len = 0;
        Node<T>* cur = Head;
        Node<T>* cur2 = Head;
        while (cur)
        {
            cur = cur->getNext();
            len++;
        }
        cur = Head;
        for (int i = 0; i < len / 2; i++)
            cur2 = cur2->getNext();
        Node<T>* temp = cur2->getNext();
        cur2->setNext(nullptr);
        cur2 = temp;


        reverse(cur2);
        while (cur && cur2)
        {
            Node<T>* t1 = cur->getNext();
            Node<T>* t2 = cur2->getNext();
            cur->setNext(cur2);
            cur2->setNext(t1);
            cur = t1;
            cur2 = t2;
        }
    }
};