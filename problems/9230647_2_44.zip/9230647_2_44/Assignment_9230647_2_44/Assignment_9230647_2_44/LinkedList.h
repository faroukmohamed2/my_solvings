#pragma once
#ifndef _LINKED_LIST_H
#define _LINKED_LIST_H
#include "Node.h"
template <typename T>
class LinkedList
{

private:
	Node<T>* Head;	//Pointer to the head of the list
	//You can add tail pointer too (depending on your problem)
public:


	LinkedList()
	{
		Head = nullptr;
	}
	LinkedList(LinkedList& l)
	{
		this->Head = l.Head;
	}
	//List is being desturcted ==> delete all items in the list
	~LinkedList()
	{
		DeleteAll();
	}
	////////////////////////////////////////////////////////////////////////
	/*
	* Function: PrintList.
	* prints the values of all nodes in a linked list.
	*/
	void PrintList() const
	{
		Node<T>* p = Head;
		while (p)
		{
			cout << p->getItem(); p = p->getNext();
			cout << " ";
		}
		cout << "NULL\n";
	}
	////////////////////////////////////////////////////////////////////////
	/*
	* Function: InsertBeg.
	* Creates a new node and adds it to the beginning of a linked list.
	*
	* Parameters:
	*	- data : The value to be stored in the new node.
	*/
	void InsertBeg(const T& data)
	{
		Node<T>* R = new Node<T>(data);
		R->setNext(Head);
		Head = R;

	}
	////////////////////////////////////////////////////////////////////////
	/*
	* Function: DeleteAll.
	* Deletes all nodes of the list.
	*/
	void DeleteAll()
	{
		Node<T>* P = Head;
		while (Head)
		{
			P = Head->getNext();
			delete Head;
			Head = P;
		}
	}



	////////////////     Requirements   ///////////////////
	//
	// Implement the following member functions


	//[1]InsertEnd 
	//inserts a new node at end if the list
	void InsertEnd(const T& data)
	{
		Node<T>* end = new Node<T>(data);
		Node<T>* tail;
		if (!Head)
		{
			Head = end;
			return;
		}
		for (tail = Head; tail->getNext(); tail = tail->getNext())
			;
		tail->setNext(end);
		tail = end;
	}

	//[2]Find 
	//searches for a given value in the list, returns true if found; false otherwise.
	bool Find(int Key);

	//[3]CountOccurance
	//returns how many times a certain value appeared in the list
	int CountOccurance(const T& value);

	//[4] DeleteFirst
	//Deletes the first node in the list
	void DeleteFirst();


	//[5] DeleteLast
	//Deletes the last node in the list
	void DeleteLast();

	//[6] DeleteNode
	//deletes the first node with the given value (if found) and returns true
	//if not found, returns false
	//Note: List is not sorted
	bool DeleteNode(const T& value);

	//[7] DeleteNodes
	//deletes ALL node with the given value (if found) and returns true
	//if not found, returns false
	//Note: List is not sorted
	bool DeleteNodes(const T& value);

	//[8]Merge
	//Merges the current list to another list L by making the last Node in the current list 
	//point to the first Node in list L
	void Merge(const LinkedList& L);

	//[9] Reverse
	//Reverses the linked list (without allocating any new Nodes)
	void Reverse();

	////////////////////////////////////////////////////////////////////////////
	///      23th April Assignment
	////////////////////////////////////////////////////////////////////////////
	template <class U>
	friend class LinkedList;

	template <class U>
	bool ApplyRepeatedOperation(LinkedList<U>& opp, LinkedList& repeat, LinkedList& res)
	{
		if (!repeat.Head)
			repeat.InsertEnd(2);
		if (!opp.Head)
			opp.InsertEnd('+');
		Node<T>* cur = Head;
		Node<U>* ptrOpp = opp.Head;
		Node<T>* ptrRepeat = repeat.Head;
		Node<T>* repTail = repeat.Head;
		Node<U>* oppTail = opp.Head;
		if (!cur)
			return true;
		while (oppTail->getNext())
			oppTail = oppTail->getNext();
		while (repTail->getNext())
			repTail = repTail->getNext();
		while (cur)
		{
			int sum = 0, mul = 1;
			if (!ptrRepeat)
			{
				repeat.InsertEnd(2);
				repTail = repTail->getNext();
				ptrRepeat = repTail;
			}
			if (!ptrOpp)
			{
				opp.InsertEnd('+');
				oppTail = oppTail->getNext();
				ptrOpp = oppTail;
			}
			int rep = ptrRepeat->getItem();
			char op = ptrOpp->getItem();
			if (rep > 1)
			{
				sum = 0;
				mul = 1;
				for (int i = 0; i < rep; i++)
				{
					if (!cur)
						return false;
					sum += cur->getItem();
					mul *= cur->getItem();
					cur = cur->getNext();
				}
				if (op == '+')
					res.InsertEnd(sum);
				else if (op == 'X')
					res.InsertEnd(mul);
				ptrOpp = ptrOpp->getNext();
			}
			else if (rep == 1 && op == 'S')
			{
				cur = cur->getNext();
				ptrOpp = ptrOpp->getNext();
			}
			ptrRepeat = ptrRepeat->getNext();
		}
		return true;
	}

};
#endif