#include "LinkedQueue.h"
#include "ArrayStack.h"
#include <iostream>
using namespace std;
template <class T>
void ReverseMinusOnes(LinkedQueue<T>& Q)
{
    LinkedQueue<T> cQ;
    ArrayStack<T> stk;
    ArrayStack<T> stkrev;
    int val;
    while (Q.dequeue(val))
    {
        int peek;
        if (val != -1)
            cQ.enqueue(val);
        else
        {
            Q.peek(peek);
            cQ.enqueue(val);
            while (Q.peek(peek) && peek != -1)
            {
                Q.dequeue(val);
                stk.push(val);
            }
            int temp;
            if (stk.isEmpty() && peek == -1 && Q.peek(temp))
                cQ.enqueue(99);
            if (peek != -1)
            {
                int data;
                while (stk.pop(data))
                    stkrev.push(data);
                while (stkrev.pop(data))
                    cQ.enqueue(data);
            }
            else
            {
                int data;
                while (stk.pop(data))
                    cQ.enqueue(data);
            }
        }
    }
    while (cQ.dequeue(val))
        Q.enqueue(val);
}
template <typename T>
void PrintQueue(LinkedQueue<T> Q) {
    T K;
    while (Q.dequeue(K))
    {
        cout << K;
        if (!Q.isEmpty()) cout << " ";
    }
    cout << endl;
}
int main()
{
    // Note: Don't change the main function. 
    int n;
    int element;
    cin >> n;
    LinkedQueue<int> input;
    for (int i = 0; i < n; i++) {
        cin >> element;
        input.enqueue(element);
    }
    ReverseMinusOnes(input); PrintQueue(input);
    return 0;
}