#pragma once

#include <string>
#include <iostream>
#include "TreeNode.h"
#include "LinkedQueue.h"
using namespace std;

class BSTree
{
private:
    TreeNode* root;

    // Utility Functions - Recursive Functions --------------------------

    // Given functions
    static void rec_destroy_tree(TreeNode*& subRoot);
    void rec_ordered_family(TreeNode* r);
    //Functions to be implemented by student

public:
    void insert(int* arr, int siz, char* dir, int* pidx, int* cidx);
    // [Note]: in the above utility functions:
// we made them static --
// because they don't need an object of BSTree to be executed
// in otherwords, they don't can't with the non-static data members of BSTree (the "root" data member)
// this is a way that will prevent you from: 
// using "root" instead of the passed "subRoot" by mistake  -> syntax error
    void orderedFamily();
public:
    BSTree(void);
    ~BSTree(void);

    // Public Functions --------------------------

    // Given functions

    void destroy_tree();
    void printBreadthOrder();// not const

    // Functions to be implemented by student

    // [Note]: in the above public functions:
    // const functions are const because there is no probibility to change 
    // the root (data member) either directly (root = something) 
    // or by indirectly by passing it (by reference) to another function (utility fn here)
};
#include <iostream>
using namespace std;





//* Deletes all the nodes in the tree.
// [Note]: subRoot is passed by ref because 
//         after deleting subRoot node we will make it point to nullptr (change subRoot)
void BSTree::rec_destroy_tree(TreeNode*& subRoot)
{
    if (subRoot != nullptr)
    {
        // recursive call on left
        rec_destroy_tree(subRoot->getleft());

        // recursive call on right
        rec_destroy_tree(subRoot->getright());

        delete subRoot;
        subRoot = nullptr; // this line is why we pass subRoot by reference (subRoot = something)
    }
}

void BSTree::rec_ordered_family(TreeNode* r)
{
    if (!r)
        return;
    if (r->getright() && r->getleft())
    {
        if (r->getright()->getdata() > r->getdata() && r->getleft()->getdata() < r->getdata())
            r->setdata(r->getdata() * 10);
    }
    else if (!r->getright() && r->getleft())
    {
        if (!r->getleft()->getright() && !r->getleft()->getleft())
            r->setleft(nullptr);
    }
    else if (r->getright() && !r->getleft())
    {
        if (!r->getright()->getright() && !r->getright()->getleft())
            r->setright(nullptr);
    }
    rec_ordered_family(r->getleft());
    rec_ordered_family(r->getright());

}

void BSTree::insert(int* arr, int siz, char* dir, int* pidx, int* cidx)
{
    TreeNode** Tarr = new TreeNode * [siz];
    for (int i = 0; i < siz; i++)
    {
        Tarr[i] = new TreeNode(arr[i]);
    }
    root = Tarr[0];
    TreeNode* parent;
    TreeNode* child;
    for (int i = 0; i < siz - 1; i++)
    {
        parent = Tarr[pidx[i]];
        child = Tarr[cidx[i]];
        if (parent)
        {
            if (dir[i] == 'L')
            {
                parent->setleft(child);
            }
            else
            {
                parent->setright(child);
            }
        }
    }
}

//Functions to be implemented by student

//* return a pointer to the node that hold the maximum value in binary search tree of the passed subRoot.

//* return a pointer to the node that hold the minimum value in binary search tree of the passed subRoot.







void BSTree::orderedFamily()
{
    rec_ordered_family(root);
}

BSTree::BSTree()
{
    root = nullptr;
}


BSTree::~BSTree()
{
    destroy_tree();
}

// Public Functions ---------------------------------

// Given functions



void BSTree::destroy_tree() // not const
{
    // not const because rec_destroy_tree takes the root by reference, so may change it
    rec_destroy_tree(root);
}




// Functions to be implemented by student
void BSTree::printBreadthOrder()
{
    LinkedQueue<TreeNode*> Tree_queue;
    Tree_queue.enqueue(root);
    while (!Tree_queue.isEmpty())
    {
        TreeNode* cur;
        Tree_queue.peek(cur);
        if (cur)
            cout << cur->getdata() << " ";
        TreeNode* temp;
        Tree_queue.dequeue(temp);
        if (cur->getleft())
            Tree_queue.enqueue(cur->getleft());
        if (cur->getright())
            Tree_queue.enqueue(cur->getright());
    }
};