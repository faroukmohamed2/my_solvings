#include "BSTree.h"
#include <iostream>
using namespace std;
int main()
{
    int n;
    int* element;
    BSTree t;
    cin >> n;
    element = new int[n];
    for (int i = 0; i < n; i++)
        cin >> element[i];
    char* dir = new char[n - 1];
    int* pidx = new int[n - 1], * cidx = new int[n - 1];
    for (int i = 0; i < n - 1; i++)
    {
        cin >> dir[i] >> pidx[i] >> cidx[i];
        //
    }
    t.insert(element, n, dir, pidx, cidx);
    t.orderedFamily();
    t.printBreadthOrder();
    delete[]element;
    delete[]pidx;
    delete[]cidx;
    return 0;
}