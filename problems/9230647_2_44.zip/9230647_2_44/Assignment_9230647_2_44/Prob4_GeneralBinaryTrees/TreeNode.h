class TreeNode
{
private:
    int data;
    TreeNode* left;
    TreeNode* right;
public:
    TreeNode(int val);
    void setdata(int d);
    int getdata();
    void setright(TreeNode* p);
    TreeNode*& getright();
    //returns a pointer by reference
    //Reason for that is explained in file BSTree.cpp as a note written
    //inside the body of function BSTree::rec_insertBST

    void setleft(TreeNode* p);
    TreeNode*& getleft();
};
TreeNode::TreeNode(int val)
{
    data = val;
    left = right = nullptr;
}


void TreeNode::setdata(int d)
{
    data = d;
}
int TreeNode::getdata()
{
    return data;
}
void TreeNode::setleft(TreeNode* p)
{
    left = p;
}
TreeNode*& TreeNode::getleft()
{
    return left;
}
void TreeNode::setright(TreeNode* p)
{
    right = p;
}
TreeNode*& TreeNode::getright()
{
    return right;
}